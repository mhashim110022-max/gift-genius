
import React, { useState, useEffect, useMemo } from 'react';
import { AppView, Person } from './types';
import Dashboard from './components/Dashboard';
import RecipientList from './components/RecipientList';
import AddRecipient from './components/AddRecipient';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import GiftPlanner from './components/GiftPlanner';
import ProUpgradeModal from './components/ProUpgradeModal';
import Login from './components/Login';

const LOCAL_STORAGE_KEY = 'gift_genius_people';
const PRO_STATUS_KEY = 'gift_genius_pro_status';
const LAST_CHECK_KEY = 'gift_genius_last_check';
const AUTH_KEY = 'gift_genius_auth';

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [view, setView] = useState<AppView>(AppView.DASHBOARD);
  const [people, setPeople] = useState<Person[]>([]);
  const [isPro, setIsPro] = useState(false);
  const [hasPaidBefore, setHasPaidBefore] = useState(false);
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [selectedPersonId, setSelectedPersonId] = useState<string | null>(null);

  // Initialize data
  useEffect(() => {
    // Check Auth
    const auth = localStorage.getItem(AUTH_KEY);
    if (auth === 'true') {
      setIsAuthenticated(true);
    }

    const savedPeople = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (savedPeople) {
      setPeople(JSON.parse(savedPeople));
    } else {
      const mock: Person[] = [
        {
          id: '1',
          name: 'Sarah Miller',
          birthday: '2025-05-15',
          relationship: 'Sister',
          interests: 'Pottery, Italian cooking, true crime podcasts',
          notes: 'Favorite color is sage green.',
          email: 'sarah.m@example.com',
          phone: '+91 99999 11111',
          isProAutoSend: false
        },
        {
          id: '2',
          name: 'Marcus Chen',
          birthday: '2025-11-02',
          relationship: 'Best Friend',
          interests: 'Vintage watches, cycling, espresso culture',
          notes: 'Moving into a new apartment soon.',
          email: 'marcus.c@example.com',
          phone: '+91 88888 22222',
          isProAutoSend: true
        }
      ];
      setPeople(mock);
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(mock));
    }

    const savedPro = localStorage.getItem(PRO_STATUS_KEY);
    if (savedPro) {
      const { isPro, hasPaidBefore } = JSON.parse(savedPro);
      setIsPro(isPro);
      setHasPaidBefore(hasPaidBefore);
    }
  }, []);

  const savePeople = (newPeople: Person[]) => {
    setPeople(newPeople);
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(newPeople));
  };

  // Automatic Birthday Checker (Simulation for Pro Users)
  useEffect(() => {
    if (!isAuthenticated || !isPro || people.length === 0) return;

    const today = new Date();
    const todayStr = today.toISOString().split('T')[0].substring(5); // MM-DD
    const currentYear = today.getFullYear();
    const lastCheck = localStorage.getItem(LAST_CHECK_KEY);
    const todayFull = today.toISOString().split('T')[0];

    if (lastCheck === todayFull) return; // Only check once per day

    let updated = false;
    const newPeople = people.map(person => {
      const bdayStr = person.birthday.substring(5); // MM-DD
      
      if (bdayStr === todayStr && person.isProAutoSend && person.lastSentYear !== currentYear) {
        updated = true;
        setTimeout(() => {
          alert(`🎁 [PRO AUTO-SEND SUCCESS]\n\nA personalized greeting and $50 Amazon Digital Gift Card has been sent to ${person.name}!\n\nEmail: ${person.email}\nTimestamp: ${new Date().toLocaleString()}`);
        }, 1000);

        return { ...person, lastSentYear: currentYear };
      }
      return person;
    });

    if (updated) {
      savePeople(newPeople);
    }
    
    localStorage.setItem(LAST_CHECK_KEY, todayFull);
  }, [isPro, people, isAuthenticated]);

  const handleLogin = () => {
    setIsAuthenticated(true);
    localStorage.setItem(AUTH_KEY, 'true');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem(AUTH_KEY);
  };

  const saveProStatus = (pro: boolean, paid: boolean) => {
    setIsPro(pro);
    setHasPaidBefore(paid);
    localStorage.setItem(PRO_STATUS_KEY, JSON.stringify({ isPro: pro, hasPaidBefore: paid }));
  };

  const handlePaymentSuccess = () => {
    saveProStatus(true, true);
    setShowUpgradeModal(false);
  };

  const handleAddPerson = (p: Person) => {
    savePeople([...people, p]);
    setView(AppView.PEOPLE);
  };

  const handleDeletePerson = (id: string) => {
    savePeople(people.filter(p => p.id !== id));
  };

  const handleUpdatePerson = (updated: Person) => {
    savePeople(people.map(p => p.id === updated.id ? updated : p));
  };

  const openGiftPlanner = (id: string) => {
    setSelectedPersonId(id);
    setView(AppView.GIFT_PLANNER);
  };

  const selectedPerson = useMemo(() => 
    people.find(p => p.id === selectedPersonId) || null
  , [people, selectedPersonId]);

  if (!isAuthenticated) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      <Sidebar 
        currentView={view} 
        setView={setView} 
        isPro={isPro} 
        onUpgradeClick={() => setShowUpgradeModal(true)} 
        onLogout={handleLogout}
      />
      
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Header 
          title={view === AppView.DASHBOARD ? "Dashboard" : 
                 view === AppView.PEOPLE ? "Your Inner Circle" : 
                 view === AppView.ADD_PERSON ? "Add Someone Special" : 
                 view === AppView.GIFT_PLANNER ? "Gift Strategy" : "Settings"} 
        />
        
        <main className="flex-1 overflow-y-auto p-4 md:p-8">
          {view === AppView.DASHBOARD && (
            <Dashboard 
              people={people} 
              onPlanGift={openGiftPlanner} 
              isPro={isPro}
              onUpdate={handleUpdatePerson}
            />
          )}
          
          {view === AppView.PEOPLE && (
            <RecipientList 
              people={people} 
              onDelete={handleDeletePerson} 
              onPlanGift={openGiftPlanner}
              onUpdate={handleUpdatePerson}
              isPro={isPro}
            />
          )}
          
          {view === AppView.ADD_PERSON && (
            <AddRecipient onAdd={handleAddPerson} />
          )}

          {view === AppView.GIFT_PLANNER && selectedPerson && (
            <GiftPlanner 
              person={selectedPerson} 
              onBack={() => setView(AppView.PEOPLE)} 
            />
          )}
        </main>
      </div>

      {showUpgradeModal && (
        <ProUpgradeModal 
          hasPaidBefore={hasPaidBefore}
          onClose={() => setShowUpgradeModal(false)}
          onSuccess={handlePaymentSuccess}
        />
      )}
    </div>
  );
};

export default App;
