
import React, { useState } from 'react';
import { Person } from '../types';

interface AddPersonProps {
  onAdd: (p: Person) => void;
}

const AddPerson: React.FC<AddPersonProps> = ({ onAdd }) => {
  const [formData, setFormData] = useState({
    name: '',
    birthday: '',
    relationship: '',
    interests: '',
    notes: '',
    email: '',
    phone: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newPerson: Person = {
      ...formData,
      id: Math.random().toString(36).substr(2, 9),
      isProAutoSend: false
    };
    onAdd(newPerson);
  };

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-3xl p-8 shadow-sm border border-slate-100 animate-in slide-in-from-right-4 duration-500">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">Add Someone Special</h2>
        <p className="text-slate-500">Provide their contact details for automated digital card delivery.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700">Full Name</label>
            <input
              required
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-rose-300 focus:ring focus:ring-rose-50 focus:ring-opacity-50 outline-none transition-all"
              placeholder="e.g. John Doe"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700">Birthday</label>
            <input
              required
              type="date"
              value={formData.birthday}
              onChange={(e) => setFormData({ ...formData, birthday: e.target.value })}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-rose-300 focus:ring focus:ring-rose-50 focus:ring-opacity-50 outline-none transition-all"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700">Email Address</label>
            <input
              required
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-rose-300 focus:ring focus:ring-rose-50 focus:ring-opacity-50 outline-none transition-all"
              placeholder="john@example.com"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700">Phone Number</label>
            <input
              required
              type="tel"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-rose-300 focus:ring focus:ring-rose-50 focus:ring-opacity-50 outline-none transition-all"
              placeholder="+91 98765 43210"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-semibold text-slate-700">Relationship</label>
          <select
            required
            value={formData.relationship}
            onChange={(e) => setFormData({ ...formData, relationship: e.target.value })}
            className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-rose-300 focus:ring focus:ring-rose-50 focus:ring-opacity-50 outline-none transition-all appearance-none"
          >
            <option value="">Select relationship</option>
            <option value="Family">Family</option>
            <option value="Friend">Friend</option>
            <option value="Colleague">Colleague</option>
            <option value="Partner">Partner</option>
            <option value="Other">Other</option>
          </select>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-semibold text-slate-700">Interests & Hobbies</label>
          <textarea
            required
            rows={3}
            value={formData.interests}
            onChange={(e) => setFormData({ ...formData, interests: e.target.value })}
            className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-rose-300 focus:ring focus:ring-rose-50 focus:ring-opacity-50 outline-none transition-all"
            placeholder="e.g. Loves gardening, coffee enthusiast..."
          />
        </div>

        <div className="pt-4">
          <button
            type="submit"
            className="w-full py-4 bg-rose-500 text-white rounded-2xl font-bold shadow-lg shadow-rose-100 hover:bg-rose-600 hover:shadow-rose-200 transition-all active:scale-[0.98]"
          >
            Save Recipient
          </button>
        </div>
      </form>
    </div>
  );
};

export default AddPerson;
