
import React from 'react';
import { Person } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface DashboardProps {
  people: Person[];
  onPlanGift: (id: string) => void;
  isPro: boolean;
  onUpdate: (updated: Person) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ people, onPlanGift, isPro, onUpdate }) => {
  const today = new Date();
  const currentYear = today.getFullYear();
  
  const sortedUpcoming = [...people].sort((a, b) => {
    const da = new Date(a.birthday);
    const db = new Date(b.birthday);
    da.setFullYear(today.getFullYear());
    db.setFullYear(today.getFullYear());
    if (da < today) da.setFullYear(today.getFullYear() + 1);
    if (db < today) db.setFullYear(today.getFullYear() + 1);
    return da.getTime() - db.getTime();
  });

  const getDaysUntil = (dateStr: string) => {
    const bday = new Date(dateStr);
    bday.setFullYear(today.getFullYear());
    if (bday < today) bday.setFullYear(today.getFullYear() + 1);
    const diff = bday.getTime() - today.getTime();
    return Math.ceil(diff / (1000 * 3600 * 24));
  };

  const toggleAutoSend = (p: Person) => {
    if (!isPro) {
      alert("Please upgrade to Pro to enable automated digital card delivery!");
      return;
    }
    onUpdate({ ...p, isProAutoSend: !p.isProAutoSend });
  };

  const chartData = [
    { name: 'Jan-Mar', gifts: people.filter(p => {
      const m = new Date(p.birthday).getMonth();
      return m >= 0 && m <= 2;
    }).length || 1 },
    { name: 'Apr-Jun', gifts: people.filter(p => {
      const m = new Date(p.birthday).getMonth();
      return m >= 3 && m <= 5;
    }).length || 2 },
    { name: 'Jul-Sep', gifts: people.filter(p => {
      const m = new Date(p.birthday).getMonth();
      return m >= 6 && m <= 8;
    }).length || 1 },
    { name: 'Oct-Dec', gifts: people.filter(p => {
      const m = new Date(p.birthday).getMonth();
      return m >= 9 && m <= 11;
    }).length || 1 },
  ];

  const COLORS = ['#fda4af', '#f43f5e', '#e11d48', '#be123c'];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex items-center space-x-4">
            <div className="bg-rose-100 w-12 h-12 rounded-2xl flex items-center justify-center text-rose-500 text-xl">
              🎂
            </div>
            <div>
              <p className="text-slate-500 text-sm">Upcoming Next 30 Days</p>
              <p className="text-2xl font-bold text-slate-800">
                {people.filter(p => getDaysUntil(p.birthday) <= 30).length} Occasions
              </p>
            </div>
          </div>
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex items-center space-x-4">
            <div className="bg-indigo-100 w-12 h-12 rounded-2xl flex items-center justify-center text-indigo-500 text-xl">
              ✨
            </div>
            <div>
              <p className="text-slate-500 text-sm">Pro Auto-Sends</p>
              <p className="text-2xl font-bold text-slate-800">
                {people.filter(p => p.isProAutoSend).length} Scheduled
              </p>
            </div>
          </div>

          <div className="md:col-span-2 bg-white p-8 rounded-3xl shadow-sm border border-slate-100 h-80">
            <h3 className="text-lg font-semibold text-slate-800 mb-4">Yearly Occasion Distribution</h3>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <Tooltip cursor={{fill: '#f8fafc'}} />
                <Bar dataKey="gifts" radius={[8, 8, 0, 0]} barSize={40}>
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 overflow-hidden flex flex-col">
          <h3 className="text-lg font-semibold text-slate-800 mb-6 flex items-center justify-between">
            Upcoming Birthdays
            <span className="text-xs font-medium text-rose-500 bg-rose-50 px-2 py-1 rounded-lg">Coming soon</span>
          </h3>
          <div className="flex-1 space-y-4 overflow-y-auto pr-2 custom-scrollbar">
            {sortedUpcoming.map((p) => {
              const days = getDaysUntil(p.birthday);
              const wasSentToday = p.lastSentYear === currentYear && days === 365; // days 365 means bday is today/passed
              
              return (
                <div key={p.id} className="group p-4 rounded-2xl hover:bg-slate-50 transition-all border border-transparent hover:border-slate-100">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h4 className="font-semibold text-slate-800">{p.name}</h4>
                      <p className="text-xs text-slate-400">{p.relationship}</p>
                    </div>
                    <div className={`px-2 py-1 rounded-md text-[10px] font-bold uppercase ${
                      wasSentToday ? 'bg-green-100 text-green-600' :
                      days < 7 ? 'bg-rose-100 text-rose-600' : 'bg-slate-100 text-slate-500'
                    }`}>
                      {wasSentToday ? 'Sent Today!' : `${days} days`}
                    </div>
                  </div>

                  <div className="mt-4 flex items-center justify-between">
                    <label className="flex items-center cursor-pointer group/toggle">
                      <div className="relative">
                        <input 
                          type="checkbox" 
                          className="sr-only" 
                          checked={p.isProAutoSend} 
                          onChange={() => toggleAutoSend(p)}
                        />
                        <div className={`block w-8 h-4.5 rounded-full transition-colors ${p.isProAutoSend ? 'bg-indigo-500' : 'bg-slate-200'}`}></div>
                        <div className={`absolute left-0.5 top-0.5 bg-white w-3.5 h-3.5 rounded-full transition-transform ${p.isProAutoSend ? 'translate-x-3.5' : ''}`}></div>
                      </div>
                      <span className={`ml-2 text-[10px] font-bold tracking-tight transition-colors ${p.isProAutoSend ? 'text-indigo-600' : 'text-slate-400 group-hover/toggle:text-slate-600'}`}>
                        {p.isProAutoSend ? 'Auto-Send Active ✨' : 'Auto-Send Off'}
                      </span>
                    </label>

                    <button 
                      onClick={() => onPlanGift(p.id)}
                      className="text-xs font-bold text-rose-500 hover:text-rose-600 transition-colors opacity-0 group-hover:opacity-100"
                    >
                      Plan →
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
