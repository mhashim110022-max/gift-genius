
import React, { useState, useEffect } from 'react';
import { Person, GiftSuggestion } from '../types';
import { getGiftSuggestions } from '../services/geminiService';

interface GiftPlannerProps {
  person: Person;
  onBack: () => void;
}

const GiftPlanner: React.FC<GiftPlannerProps> = ({ person, onBack }) => {
  const [loading, setLoading] = useState(true);
  const [suggestions, setSuggestions] = useState<GiftSuggestion[]>([]);
  const [error, setError] = useState<string | null>(null);

  const fetchSuggestions = async () => {
    setLoading(true);
    setError(null);
    try {
      const ideas = await getGiftSuggestions(person.interests, person.relationship);
      setSuggestions(ideas);
    } catch (err) {
      setError("Failed to generate suggestions. Please check your API key.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSuggestions();
  }, [person]);

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-500">
      <div className="flex items-center space-x-4">
        <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-400">
          ←
        </button>
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Gift Ideas for {person.name}</h2>
          <p className="text-slate-500">Curated by Gift Genius AI based on their unique personality.</p>
        </div>
      </div>

      {loading ? (
        <div className="bg-white rounded-3xl p-12 border border-slate-100 flex flex-col items-center justify-center text-center space-y-6">
          <div className="relative">
            <div className="w-16 h-16 border-4 border-rose-100 border-t-rose-500 rounded-full animate-spin"></div>
            <span className="absolute inset-0 flex items-center justify-center text-xl">🧠</span>
          </div>
          <div>
            <h3 className="text-xl font-bold text-slate-800 mb-2">Analyzing Interests...</h3>
            <p className="text-slate-500">Scanning categories: {person.interests.split(',').slice(0, 2).join(', ')} and more.</p>
          </div>
          <div className="flex gap-2">
            {[1, 2, 3].map(i => (
              <div key={i} className="w-2 h-2 bg-rose-200 rounded-full animate-bounce" style={{ animationDelay: `${i * 0.2}s` }}></div>
            ))}
          </div>
        </div>
      ) : error ? (
        <div className="bg-rose-50 border border-rose-100 p-8 rounded-3xl text-center">
          <p className="text-rose-600 mb-4">{error}</p>
          <button 
            onClick={fetchSuggestions}
            className="px-6 py-2 bg-rose-500 text-white rounded-xl hover:bg-rose-600 transition-all"
          >
            Retry Analysis
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {suggestions.map((gift, idx) => (
            <div key={idx} className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm flex flex-col h-full hover:shadow-md transition-all">
              <div className="mb-4">
                <span className="inline-block px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-[10px] font-bold uppercase tracking-wider mb-2">
                  {gift.category}
                </span>
                <h3 className="text-lg font-bold text-slate-800 leading-tight mb-2">{gift.title}</h3>
                <p className="text-sm text-slate-600 line-clamp-3 mb-4">{gift.description}</p>
              </div>

              <div className="mt-auto space-y-4">
                <div className="bg-slate-50 p-4 rounded-2xl">
                  <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wide mb-1">Why it fits</p>
                  <p className="text-xs text-slate-700 italic">"{gift.reasoning}"</p>
                </div>
                
                <div className="flex items-center justify-between text-sm">
                  <span className="font-bold text-rose-500">{gift.priceRange}</span>
                  <button className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl font-semibold hover:bg-slate-200 transition-colors">
                    Find Online
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {!loading && !error && (
        <div className="bg-gradient-to-r from-rose-500 to-rose-600 rounded-3xl p-8 text-white shadow-xl shadow-rose-100 flex flex-col md:flex-row items-center justify-between">
          <div className="mb-6 md:mb-0 text-center md:text-left">
            <h3 className="text-xl font-bold mb-2">Ready to secure this gift?</h3>
            <p className="text-rose-100 max-w-md">Schedule a reminder or use the Pro auto-send feature to ensure you never miss the deadline.</p>
          </div>
          <div className="flex gap-4">
            <button className="px-6 py-3 bg-white text-rose-600 rounded-2xl font-bold hover:bg-rose-50 transition-colors shadow-lg">
              Set Reminder
            </button>
            <button className="px-6 py-3 bg-rose-900/30 text-white rounded-2xl font-bold hover:bg-rose-900/40 transition-colors border border-white/20">
              Add to Wishlist
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default GiftPlanner;
