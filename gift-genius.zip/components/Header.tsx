
import React from 'react';

interface HeaderProps {
  title: string;
}

const Header: React.FC<HeaderProps> = ({ title }) => {
  return (
    <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-8 z-10">
      <h1 className="text-xl font-semibold text-slate-800">{title}</h1>
      <div className="flex items-center space-x-4">
        <button className="text-slate-400 hover:text-slate-600 transition-colors">
          <span className="text-xl">🔔</span>
        </button>
        <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-slate-500 text-sm font-medium">
          JD
        </div>
      </div>
    </header>
  );
};

export default Header;
