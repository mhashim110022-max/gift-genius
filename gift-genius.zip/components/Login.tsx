
import React, { useState } from 'react';

interface LoginProps {
  onLogin: () => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState<'phone' | 'otp'>('phone');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (phone.length < 10) {
      setError('Please enter a valid phone number');
      return;
    }
    setLoading(true);
    setError('');
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      setStep('otp');
    }, 1500);
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.length < 4) {
      setError('Please enter a valid OTP');
      return;
    }
    setLoading(true);
    setError('');
    // Simulate verification (Mock code: 123456)
    setTimeout(() => {
      setLoading(false);
      onLogin();
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-[40px] shadow-xl overflow-hidden animate-in zoom-in-95 duration-500 border border-slate-100">
        <div className="bg-gradient-to-br from-rose-500 to-rose-600 p-10 text-center text-white relative">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-white/20 backdrop-blur-md rounded-3xl text-4xl mb-6 shadow-xl animate-bounce">
            🎁
          </div>
          <h1 className="text-3xl font-bold font-serif mb-2">Gift Genius</h1>
          <p className="text-rose-100 text-sm opacity-90">Your AI Anti-Procrastination Assistant</p>
        </div>

        <div className="p-10">
          {step === 'phone' ? (
            <form onSubmit={handleSendOtp} className="space-y-6 animate-in slide-in-from-right-4 duration-300">
              <div className="space-y-2">
                <h2 className="text-xl font-bold text-slate-800">Welcome Back</h2>
                <p className="text-slate-500 text-sm">Enter your phone number to get started.</p>
              </div>

              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 font-bold border-r border-slate-200 pr-3 z-10">+91</span>
                <input
                  type="tel"
                  required
                  maxLength={10}
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                  className="w-full pl-20 pr-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-lg font-bold text-slate-900 outline-none focus:ring-2 focus:ring-rose-500 focus:bg-white transition-all placeholder:text-slate-300"
                  placeholder="99999 00000"
                />
              </div>

              {error && <p className="text-rose-500 text-xs font-bold text-center uppercase tracking-wider">{error}</p>}

              <button
                type="submit"
                disabled={loading}
                className="w-full py-4 bg-rose-500 text-white rounded-2xl font-bold text-lg hover:bg-rose-600 shadow-xl shadow-rose-100 active:scale-95 transition-all flex items-center justify-center space-x-2"
              >
                {loading ? (
                  <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                ) : (
                  <span>Send OTP</span>
                )}
              </button>
            </form>
          ) : (
            <form onSubmit={handleVerifyOtp} className="space-y-6 animate-in slide-in-from-right-4 duration-300">
              <div className="space-y-2">
                <h2 className="text-xl font-bold text-slate-800">Verify Code</h2>
                <p className="text-slate-500 text-sm">We've sent a 6-digit code to <span className="font-bold text-slate-700">+91 {phone}</span></p>
              </div>

              <div className="relative">
                <input
                  type="text"
                  required
                  maxLength={6}
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                  className="w-full px-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-center text-3xl font-black tracking-[0.3em] text-slate-900 outline-none focus:ring-2 focus:ring-rose-500 focus:bg-white transition-all placeholder:text-slate-200"
                  placeholder="000000"
                />
              </div>

              {error && <p className="text-rose-500 text-xs font-bold text-center uppercase tracking-wider">{error}</p>}

              <button
                type="submit"
                disabled={loading}
                className="w-full py-4 bg-slate-800 text-white rounded-2xl font-bold text-lg hover:bg-black shadow-xl active:scale-95 transition-all flex items-center justify-center space-x-2"
              >
                {loading ? (
                  <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                ) : (
                  <span>Login to Genius</span>
                )}
              </button>

              <button
                type="button"
                onClick={() => setStep('phone')}
                className="w-full text-slate-400 text-sm font-medium hover:text-rose-500 transition-colors"
              >
                Change Phone Number
              </button>
            </form>
          )}
        </div>

        <div className="px-10 py-6 bg-slate-50 border-t border-slate-100 text-center">
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">
            Trusted by 50,000+ Gift Givers
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
