import React, { useState, useEffect } from 'react';

// --- CONFIGURATION ---
const MERCHANT_UPI_ID = "muhammad.wani@fam"; 
const MERCHANT_NAME = "Gift Genius Pro";
// ---------------------

interface ProUpgradeModalProps {
  hasPaidBefore: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

const ProUpgradeModal: React.FC<ProUpgradeModalProps> = ({ hasPaidBefore, onClose, onSuccess }) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [showVerification, setShowVerification] = useState(false);
  const [showQr, setShowQr] = useState(false);
  const [copied, setCopied] = useState(false);
  const [utr, setUtr] = useState('');
  const [senderName, setSenderName] = useState('');
  const [verificationStep, setVerificationStep] = useState(0);
  const [error, setError] = useState<string | null>(null);
  
  const price = hasPaidBefore ? 199 : 9;

  const upiLink = `upi://pay?pa=${MERCHANT_UPI_ID}&pn=${encodeURIComponent(MERCHANT_NAME)}&am=${price}&cu=INR&tn=${encodeURIComponent('Gift Genius Pro Upgrade')}`;
  
  // Fixed: Corrected the string syntax and extracted only the image source URL
  const qrCodeUrl = "https://i.ibb.co/zV2jxV1y/payment-here.png";

  const handlePayClick = () => {
    window.location.href = upiLink;
    setTimeout(() => {
      setShowVerification(true);
    }, 2000);
  };

  const copyUpiId = () => {
    navigator.clipboard.writeText(MERCHANT_UPI_ID);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const steps = [
    "Establishing secure bank handshake...",
    "Validating UTR against settlement logs...",
    "Confirming sender identity...",
    "Syncing digital card servers...",
    "Finalizing Pro activation..."
  ];

  const handleVerify = () => {
    if (utr.length < 12) {
      setError("Please enter a valid 12-digit UTR number.");
      return;
    }
    if (senderName.trim().length < 3) {
      setError("Please enter your full Name as per Bank records.");
      return;
    }

    setError(null);
    setIsProcessing(true);
    setVerificationStep(0);

    let currentStep = 0;
    const interval = setInterval(() => {
      currentStep++;
      if (currentStep < steps.length) {
        setVerificationStep(currentStep);
      } else {
        clearInterval(interval);
        setTimeout(() => {
          setIsProcessing(false);
          onSuccess();
        }, 1200);
      }
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-md animate-in fade-in duration-300">
      <div className="bg-white rounded-[40px] w-full max-w-md overflow-hidden shadow-2xl animate-in zoom-in-95 duration-300 border border-slate-100">
        
        {/* Top Header */}
        <div className="bg-gradient-to-br from-indigo-600 to-indigo-800 p-8 text-center text-white relative">
          {!isProcessing && (
            <button 
              onClick={onClose}
              className="absolute top-6 right-6 w-8 h-8 flex items-center justify-center bg-white/20 hover:bg-white/30 rounded-full transition-colors"
            >
              ✕
            </button>
          )}
          <div className="inline-flex items-center justify-center w-20 h-20 bg-white/20 backdrop-blur-md rounded-3xl text-4xl mb-4 shadow-xl">
            {isProcessing ? '🛡️' : '✨'}
          </div>
          <h2 className="text-2xl font-bold font-serif">
            {isProcessing ? 'Verifying Funds' : 'Go Digital Pro'}
          </h2>
          <p className="text-indigo-100 text-sm mt-1">
            {isProcessing ? 'Direct Bank-to-Wallet Settlement' : 'Automated Digital Gift Delivery'}
          </p>
        </div>

        <div className="p-8">
          {!showVerification && !isProcessing ? (
            <>
              {!showQr ? (
                <div className="animate-in fade-in slide-in-from-bottom-2 duration-300">
                  <div className="space-y-4 mb-8">
                    <div className="flex items-start space-x-3 text-sm">
                      <div className="w-6 h-6 rounded-full bg-indigo-50 flex items-center justify-center text-indigo-500 shrink-0">✓</div>
                      <div className="text-slate-600">
                        <span className="font-bold text-slate-800">Instant Digital Delivery:</span> Auto-sends Amazon/Digital cards on time.
                      </div>
                    </div>
                    <div className="flex items-start space-x-3 text-sm">
                      <div className="w-6 h-6 rounded-full bg-indigo-50 flex items-center justify-center text-indigo-500 shrink-0">✓</div>
                      <div className="text-slate-600">
                        <span className="font-bold text-slate-800">Personalized AI Greetings:</span> Gemini writes custom notes for every card.
                      </div>
                    </div>
                  </div>

                  <div className="bg-slate-50 rounded-3xl p-6 border border-slate-100 mb-8 text-center">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-2">Exclusive Pro Plan</span>
                    <div className="flex items-baseline justify-center space-x-2">
                      <span className="text-4xl font-black text-slate-800">₹{price}</span>
                      <span className="text-slate-400 text-sm">/ year</span>
                    </div>
                  </div>

                  <div className="flex flex-col space-y-3">
                    <button
                      onClick={handlePayClick}
                      className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold text-lg hover:bg-indigo-700 shadow-xl shadow-indigo-100 active:scale-95 transition-all flex items-center justify-center space-x-2"
                    >
                      <span>Pay with UPI App</span>
                      <img src="https://upload.wikimedia.org/wikipedia/commons/e/e1/UPI-Logo-vector.svg" alt="UPI" className="h-4 brightness-0 invert" />
                    </button>
                    <button
                      onClick={() => setShowQr(true)}
                      className="w-full py-3 bg-white border-2 border-slate-200 text-slate-700 rounded-2xl font-bold hover:bg-slate-50 transition-all flex items-center justify-center space-x-2"
                    >
                      <span>📷</span>
                      <span>Show QR Code</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="animate-in zoom-in-95 duration-300 text-center">
                  <div className="relative inline-block mb-4">
                    <div className="bg-white p-4 rounded-3xl border-2 border-indigo-100 shadow-lg">
                      <img 
                        src={qrCodeUrl} 
                        alt="UPI Payment QR Code" 
                        className="w-56 h-56 mx-auto object-contain"
                        onError={() => setError('Failed to load QR code. Please check your internet connection or use the UPI App option.')}
                      />
                    </div>
                    <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 bg-indigo-600 text-white text-[10px] font-bold px-3 py-1 rounded-full whitespace-nowrap shadow-md">
                      SCAN WITH ANY UPI APP
                    </div>
                  </div>
                  
                  <div className="mb-6">
                    <p className="text-slate-800 font-bold text-lg">₹{price}</p>
                    <p className="text-slate-500 text-xs">Merchant: {MERCHANT_NAME}</p>
                  </div>
                  
                  {error && <p className="text-rose-500 text-[10px] font-bold text-center mb-4 px-4">{error}</p>}

                  <div className="flex flex-col space-y-3">
                    <button
                      onClick={() => setShowVerification(true)}
                      className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold text-lg hover:bg-indigo-700 shadow-xl shadow-indigo-100 active:scale-95 transition-all"
                    >
                      I have Paid
                    </button>
                    <button
                      onClick={() => setShowQr(false)}
                      className="text-slate-400 text-sm font-medium hover:text-indigo-500 transition-colors"
                    >
                      ← Back to UPI App option
                    </button>
                  </div>
                </div>
              )}

              <div className="mt-6">
                <button 
                  onClick={copyUpiId}
                  className="w-full text-xs text-slate-400 hover:text-indigo-500 transition-colors font-medium text-center"
                >
                  {copied ? 'Copied ID!' : `Manual ID: ${MERCHANT_UPI_ID}`}
                </button>
              </div>
            </>
          ) : isProcessing ? (
            <div className="py-10 text-center space-y-8 animate-in fade-in duration-500">
              <div className="relative inline-block">
                <div className="w-24 h-24 border-4 border-slate-100 border-t-indigo-600 rounded-full animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-16 h-16 bg-indigo-50 rounded-full animate-pulse"></div>
                </div>
              </div>
              
              <div className="space-y-3 px-4">
                <p className="text-lg font-bold text-slate-800">
                  {steps[verificationStep]}
                </p>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden max-w-xs mx-auto">
                  <div 
                    className="bg-indigo-600 h-full transition-all duration-1000 ease-out"
                    style={{ width: `${((verificationStep + 1) / steps.length) * 100}%` }}
                  ></div>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl inline-block mt-4">
                  <p className="text-[10px] text-slate-400 uppercase font-bold tracking-tighter">Bank Record Lock</p>
                  <p className="text-xs text-slate-600 font-mono">{utr} • {senderName}</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="animate-in slide-in-from-right-4 duration-300">
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-indigo-50 rounded-full flex items-center justify-center text-indigo-500 text-2xl mx-auto mb-4">
                  🏦
                </div>
                <h3 className="text-xl font-bold text-slate-800">Secure Bank Verification</h3>
                <p className="text-slate-500 text-xs px-4 mt-1">
                  We check your UTR against our bank's settlement log to confirm funds.
                </p>
              </div>

              <div className="space-y-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Your Name (Bank Record)</label>
                  <input
                    type="text"
                    value={senderName}
                    onChange={(e) => setSenderName(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-bold outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="Enter full name"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">12-Digit UTR Number</label>
                  <input
                    type="text"
                    inputMode="numeric"
                    maxLength={12}
                    value={utr}
                    onChange={(e) => setUtr(e.target.value.replace(/\D/g, ''))}
                    className="w-full px-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-center text-2xl font-black tracking-[0.1em] text-slate-900 focus:ring-2 focus:ring-indigo-500 outline-none placeholder:text-slate-300"
                    placeholder="000000000000"
                  />
                </div>

                {error && <p className="text-rose-500 text-[10px] font-bold text-center mt-2 uppercase">{error}</p>}

                <div className="pt-2 space-y-3">
                  <button
                    onClick={handleVerify}
                    className="w-full py-4 bg-indigo-900 text-white rounded-2xl font-bold text-lg hover:bg-black shadow-xl active:scale-95 transition-all"
                  >
                    Check Bank Settlement
                  </button>
                  <button
                    onClick={() => {
                      setShowVerification(false);
                      setShowQr(false);
                    }}
                    className="w-full text-slate-400 text-xs font-medium hover:text-slate-600 transition-colors"
                  >
                    Modify Payment Details
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="px-8 py-4 bg-slate-50 border-t border-slate-100 text-center">
          <p className="text-[9px] text-slate-400 font-medium uppercase tracking-[0.1em] leading-relaxed">
            Final settlement check performed in real-time • Powered by UPI Verification Node
          </p>
        </div>
      </div>
    </div>
  );
};

export default ProUpgradeModal;