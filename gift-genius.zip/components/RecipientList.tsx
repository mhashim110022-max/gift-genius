
import React from 'react';
import { Person } from '../types';

interface PeopleListProps {
  people: Person[];
  onDelete: (id: string) => void;
  onPlanGift: (id: string) => void;
  onUpdate: (updated: Person) => void;
  isPro: boolean;
}

const PeopleList: React.FC<PeopleListProps> = ({ people, onDelete, onPlanGift, onUpdate, isPro }) => {
  const currentYear = new Date().getFullYear();
  
  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-US', {
      month: 'long',
      day: 'numeric'
    });
  };

  const toggleAutoSend = (p: Person) => {
    if (!isPro) {
      alert("Please upgrade to Pro to enable automated digital card delivery!");
      return;
    }
    onUpdate({ ...p, isProAutoSend: !p.isProAutoSend });
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-in slide-in-from-bottom-4 duration-500">
      {people.length === 0 ? (
        <div className="col-span-full py-20 flex flex-col items-center justify-center text-slate-400">
          <span className="text-6xl mb-4">📭</span>
          <p className="text-lg">No one here yet. Add your first person!</p>
        </div>
      ) : (
        people.map((p) => (
          <div key={p.id} className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 hover:shadow-md transition-all group relative">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 rounded-2xl bg-slate-50 flex items-center justify-center text-xl font-bold text-rose-400">
                  {p.name.charAt(0)}
                </div>
                <div>
                  <h3 className="font-bold text-slate-800">{p.name}</h3>
                  <p className="text-xs text-slate-500">{p.relationship}</p>
                </div>
              </div>
              <div className="flex flex-col items-end space-y-1">
                <button 
                  onClick={() => onDelete(p.id)}
                  className="text-slate-300 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-all p-1"
                >
                  🗑️
                </button>
                {p.lastSentYear === currentYear && (
                  <span className="bg-green-100 text-green-600 text-[9px] font-bold px-2 py-0.5 rounded-full uppercase tracking-tighter">
                    Sent for {currentYear}
                  </span>
                )}
              </div>
            </div>

            <div className="space-y-3 mb-6">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Contact:</span>
                <span className="text-slate-700 font-medium truncate max-w-[150px]">{p.email}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Birthday:</span>
                <span className="text-slate-700 font-medium">{formatDate(p.birthday)}</span>
              </div>
              <div className="text-xs">
                <p className="text-slate-400 mb-1">Interests:</p>
                <div className="flex flex-wrap gap-1">
                  {p.interests.split(',').slice(0, 3).map((interest, i) => (
                    <span key={i} className="bg-slate-50 text-slate-600 px-2 py-0.5 rounded text-[10px] font-medium">
                      {interest.trim()}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-50 flex flex-col space-y-3">
              <div className="flex items-center justify-between">
                <label className="flex items-center cursor-pointer">
                  <div className="relative">
                    <input 
                      type="checkbox" 
                      className="sr-only" 
                      checked={p.isProAutoSend} 
                      onChange={() => toggleAutoSend(p)}
                    />
                    <div className={`block w-10 h-6 rounded-full transition-colors ${p.isProAutoSend ? 'bg-indigo-500' : 'bg-slate-200'}`}></div>
                    <div className={`dot absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform ${p.isProAutoSend ? 'translate-x-4' : ''}`}></div>
                  </div>
                  <div className="ml-3 text-[11px] font-bold text-slate-600">
                    Auto-Send Digital Card {p.isProAutoSend && <span className="text-indigo-500">✨</span>}
                  </div>
                </label>
              </div>
              
              <button 
                onClick={() => onPlanGift(p.id)}
                className="w-full py-2 bg-slate-800 text-white rounded-xl text-sm font-semibold hover:bg-slate-900 transition-all shadow-sm flex items-center justify-center space-x-2"
              >
                <span>💡</span>
                <span>Gift Strategy</span>
              </button>
            </div>
          </div>
        ))
      )}
    </div>
  );
};

export default PeopleList;
