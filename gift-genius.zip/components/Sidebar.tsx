
import React from 'react';
import { AppView } from '../types';

interface SidebarProps {
  currentView: AppView;
  setView: (view: AppView) => void;
  isPro: boolean;
  onUpgradeClick: () => void;
  onLogout: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, setView, isPro, onUpgradeClick, onLogout }) => {
  const menuItems = [
    { id: AppView.DASHBOARD, icon: '🏠', label: 'Dashboard' },
    { id: AppView.PEOPLE, icon: '👥', label: 'People' },
    { id: AppView.ADD_PERSON, icon: '➕', label: 'Add Person' },
  ];

  return (
    <div className="w-64 bg-white border-r border-slate-200 hidden md:flex flex-col">
      <div className="p-6">
        <div className="flex items-center space-x-2 text-rose-500 mb-8">
          <div className="bg-rose-100 p-2 rounded-lg">
            <span className="text-2xl">🎁</span>
          </div>
          <span className="text-xl font-bold font-serif tracking-tight text-slate-800">Gift Genius</span>
        </div>

        <nav className="space-y-1">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setView(item.id)}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all ${
                currentView === item.id
                  ? 'bg-rose-50 text-rose-600 font-semibold shadow-sm'
                  : 'text-slate-500 hover:bg-slate-50'
              }`}
            >
              <span>{item.icon}</span>
              <span>{item.label}</span>
            </button>
          ))}
          <button
            onClick={onLogout}
            className="w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-slate-400 hover:bg-rose-50 hover:text-rose-500 transition-all mt-4"
          >
            <span>🚪</span>
            <span>Logout</span>
          </button>
        </nav>
      </div>

      <div className="mt-auto p-6">
        <div className={`p-4 rounded-2xl border transition-all duration-300 ${isPro ? 'bg-indigo-50 border-indigo-200 shadow-sm' : 'bg-slate-50 border-slate-100'}`}>
          <div className="flex items-center justify-between mb-2">
            <span className={`text-xs font-bold uppercase tracking-wider ${isPro ? 'text-indigo-600' : 'text-slate-400'}`}>
              {isPro ? 'Pro Member' : 'Basic Tier'}
            </span>
            {isPro && <span className="text-indigo-600 animate-pulse">✨</span>}
          </div>
          <p className="text-sm text-slate-600 mb-4 leading-relaxed">
            {isPro ? 'Auto-send digital gift cards is active.' : 'Unlock auto-send for digital cards & AI greetings.'}
          </p>
          <button 
            onClick={onUpgradeClick}
            className={`w-full py-2 px-4 rounded-lg font-medium text-sm transition-all shadow-sm ${
              isPro 
                ? 'bg-white text-indigo-600 border border-indigo-200 hover:bg-indigo-50' 
                : 'bg-rose-500 text-white hover:bg-rose-600'
            }`}
          >
            {isPro ? 'Manage Billing' : 'Upgrade to Pro'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
