
import { GoogleGenAI, Type } from "@google/genai";
import { GiftSuggestion } from "../types";

export const getGiftSuggestions = async (interests: string, relationship: string): Promise<GiftSuggestion[]> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  const prompt = `Suggest 3 unique and thoughtful gift ideas for a person with the following interests: "${interests}". 
  The relationship to the sender is: "${relationship}". 
  Provide creative ideas ranging from physical items to experiences.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              priceRange: { type: Type.STRING },
              reasoning: { type: Type.STRING },
              category: { type: Type.STRING }
            },
            required: ["title", "description", "priceRange", "reasoning", "category"],
            propertyOrdering: ["title", "description", "priceRange", "reasoning", "category"]
          }
        }
      },
    });

    const jsonStr = response.text.trim();
    return JSON.parse(jsonStr);
  } catch (error) {
    console.error("Error generating gift suggestions:", error);
    return [];
  }
};
