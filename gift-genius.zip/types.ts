
export interface Person {
  id: string;
  name: string;
  birthday: string; // ISO Date
  relationship: string;
  interests: string;
  notes: string;
  email: string;
  phone: string;
  isProAutoSend: boolean;
  lastSentYear?: number; // Year the last automated gift was sent
}

export interface GiftSuggestion {
  title: string;
  description: string;
  priceRange: string;
  reasoning: string;
  category: string;
}

export interface GiftHistory {
  personId: string;
  year: number;
  giftName: string;
}

export enum AppView {
  DASHBOARD = 'DASHBOARD',
  PEOPLE = 'PEOPLE',
  ADD_PERSON = 'ADD_PERSON',
  GIFT_PLANNER = 'GIFT_PLANNER',
  SETTINGS = 'SETTINGS'
}
